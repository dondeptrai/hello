# app/crud/user.py
from sqlalchemy.orm import Session
from app.models.user import User
from app.schemas.user import UserCreate

# Tạo người dùng mới
def create_user(db: Session, user: UserCreate):
    hashed_password = hash_password(user.password)  # Mã hóa mật khẩu
    new_user = User(
        name=user.name,
        email=user.email,
        hashed_password=hashed_password,
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user

# Lấy thông tin người dùng theo email
def get_user_by_email(db: Session, email: str):
    return db.query(User).filter(User.email == email).first()

# Lấy danh sách tất cả người dùng
def get_all_users(db: Session, skip: int = 0, limit: int = 10):
    return db.query(User).offset(skip).limit(limit).all()
