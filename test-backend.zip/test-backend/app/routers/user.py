from fastapi import APIRouter, Depends, status, HTTPException
from sqlalchemy.orm import Session
from app import crud, schemas
from app.database import SessionLocal
from app.models import User
import datetime

router = APIRouter()

# Hàm phụ trợ để lấy session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/users/", response_model=schemas.UserOut)
def create_user(user: schemas.UserOut):
    db = SessionLocal()
    new_user = User(
        name=user.name,
        hashed_password="hehe",
        email=user.email,
        role=user.role
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user

# GET: Lấy tất cả người dùng
@router.get("/users/", response_model=list[schemas.UserOut])
def get_users(db: Session = Depends(get_db)):
    users = db.query(User).all()  # Lấy tất cả người dùng
    return users

@router.post("/login/")
def login_user(request: schemas.LoginRequest, db: Session = Depends(get_db)):
    # Lấy thông tin từ payload
    email = request.email
    password = request.password

    # Kiểm tra người dùng trong cơ sở dữ liệu
    db_user = crud.get_user_by_email(db, email=email)
    if db_user is None:
        raise HTTPException(status_code=400, detail="Invalid credentials")

    # Kiểm tra mật khẩu
    if password != db_user.hashed_password:  # Thay bằng check mật khẩu nếu mã hóa
        raise HTTPException(status_code=400, detail="Invalid credentials")

    return {"message": "Login successful", "user_id": db_user.id}

@router.post("/register/")
def register_user(request: schemas.RegisterRequest, db: Session = Depends(get_db)):
    # Kiểm tra email đã tồn tại
    db_user = db.query(User).filter(User.email == request.email).first()
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")

    # Tạo người dùng mới
    new_user = User(
        name=request.name,
        email=request.email,
        hashed_password=request.password,  # Lưu mật khẩu (cần mã hóa trong thực tế)
        role="user",  # Mặc định role là 'user'
        created_at=datetime.datetime.utcnow(),
        updated_at=datetime.datetime.utcnow()
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    return {"message": "User registered successfully", "user_id": new_user.id}