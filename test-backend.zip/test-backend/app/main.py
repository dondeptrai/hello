from fastapi import FastAPI
from app.database import engine
from app.models import Base  # Import Base từ file base.py
from fastapi.middleware.cors import CORSMiddleware 
from app.routers import user  # Import router từ file app/routers/user.py

# Khởi tạo ứng dụng FastAPI
app = FastAPI()

# Cấu hình CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Cho phép mọi domain truy cập (bạn có thể thay thế "*" bằng domain cụ thể nếu cần)
    allow_credentials=True,
    allow_methods=["*"],  # Cho phép tất cả phương thức HTTP (GET, POST, PUT, DELETE, ...)
    allow_headers=["*"],  # Cho phép tất cả header
)

# Tạo bảng nếu chưa có
Base.metadata.create_all(bind=engine)

# Đăng ký router
app.include_router(user.router)
