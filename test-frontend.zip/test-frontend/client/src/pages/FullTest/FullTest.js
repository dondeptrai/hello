import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import CountdownTimer from "../../components/Countdown/Countdown";
import { Part, Question, Group, Answer } from '../../components/Data'; // Dữ liệu chi tiết Part và câu hỏi
import "./FullTest.css";

// Hiển thị tab Part và Navigation
const partsData = {
  'Part 1': { start: 1, end: 6 },
  'Part 2': { start: 7, end: 31 },
  'Part 3': { start: 32, end: 70 },
  'Part 4': { start: 71, end: 100 },
  'Part 5': { start: 101, end: 130 },
  'Part 6': { start: 131, end: 146 },
  'Part 7': { start: 147, end: 200 },
};

const PracticePage = () => {
  const navigate = useNavigate();
  const [selectedPart, setSelectedPart] = useState("Part 1");
  const [filteredQuestions, setFilteredQuestions] = useState([]);
  const [selectedAnswers, setSelectedAnswers] = useState({});

  const {id} = useParams();

  // Lọc câu hỏi từ Part
  const loadQuestionsForPart = (partOrder) => {
    const part = Part.find((p) => p.part_order === partOrder);
    if (part) {
      const partQuestions = Question.filter((q) => q.part_id === part.id);
      setFilteredQuestions(partQuestions);
    } else {
      setFilteredQuestions([]);
    }
  };

  // Chuyển đổi giữa các Part
  const handlePartChange = (part) => {
    setSelectedPart(part);
    loadQuestionsForPart(part);
  };

  // Lấy nội dung Group
  const getGroupContent = (groupId) => {
    const group = Group.find((g) => g.id === groupId);
    if (group) {
      return (
        <div className="group-content">
          {group.image_url1 && (
            <img src={group.image_url1} alt="Group Illustration" className="group-image" />
          )}
          {group.image_url2 && (
            <img src={group.image_url2} alt="Group Illustration" className="group-image" />
          )}
          {group.paragraph1 && <p>{group.paragraph1}</p>}
          {group.paragraph2 && <p>{group.paragraph2}</p>}
          {group.paragraph3 && <p>{group.paragraph3}</p>}
        </div>
      );
    }
    return null;
  };

  // Cập nhật câu trả lời đã chọn
  const handleAnswerChange = (questionId, answerId) => {
    setSelectedAnswers((prevState) => ({
      ...prevState,
      [questionId]: answerId, // Chỉ lưu lại một câu trả lời cho mỗi câu hỏi
    }));
  };

  // const handleScrollToQuestion = (questionId) => {
  //   const element = document.getElementById(`question-${questionId}`);
  //   if (element) {
  //     element.scrollIntoView({ behavior: "smooth", block: "center" });
  //   }
  // };

  const handleScrollToQuestion = (questionId) => {
    // Tìm Part chứa câu hỏi
    const targetPart = Object.entries(partsData).find(([_, { start, end }]) => 
      questionId >= start && questionId <= end
    );
  
    if (targetPart) {
      const [partName] = targetPart;
  
      // Nếu Part hiện tại khác Part của câu hỏi, đổi Part
      if (selectedPart !== partName) {
        setSelectedPart(partName);
        loadQuestionsForPart(partName); // Load câu hỏi của Part mới
  
        // Đợi React render trước khi cuộn
        setTimeout(() => {
          const element = document.getElementById(`question-${questionId}`);
          if (element) {
            element.scrollIntoView({ behavior: "smooth", block: "center" });
          }
        }, 0);
      } else {
        // Nếu câu hỏi trong Part hiện tại, cuộn trực tiếp
        const element = document.getElementById(`question-${questionId}`);
        if (element) {
          element.scrollIntoView({ behavior: "smooth", block: "center" });
        }
      }
    }
  };
  

  // Hiển thị danh sách câu hỏi
  const renderQuestions = () => {
    let lastGroupId = null;

    return filteredQuestions.map((question) => {
      // Kiểm tra xem có phải nhóm mới không
      const isNewGroup = question.group_id !== lastGroupId;
      lastGroupId = question.group_id;

      // Lấy phần nội dung của nhóm câu hỏi (nếu có)
      const groupContent = getGroupContent(question.group_id);

      // Tìm đáp án cho câu hỏi
      const answersForQuestion = Answer.filter((answer) => answer.question_id === question.id);

      // Kiểm tra xem câu hỏi thuộc loại Part nào (1-4 hoặc 5-7)
      const partDetails = Part.find((p) => p.id === question.part_id);
      const isContentAnswerPart3to7 = partDetails && ["Part 3", "Part 4", "Part 5", "Part 6", "Part 7"].includes(partDetails.part_order);
      console.log(partDetails);
      console.log(isContentAnswerPart3to7);

      return (
        <div key={question.id} id={`question-${question.order}`} className="question-item">
          {/* Hiển thị nội dung nhóm câu hỏi nếu có */}
          {isNewGroup && groupContent}

          {/* Nội dung câu hỏi */}
          {isContentAnswerPart3to7 ? 
            <p>{question.order} {question.content}</p>
            : <p>{question.order}</p>
          }
          

          {/* Hiển thị đáp án */}
          <div className="choices">
            {isContentAnswerPart3to7 ? (
              // Hiển thị đáp án cho Part 3, 4, 5, 6, 7 (có thể có nhiều lựa chọn)
              answersForQuestion.map((answer) => (
                <label key={answer.id} className="choice-label">
                  <input
                    type="radio"
                    name={`question-${question.id}`}
                    checked={selectedAnswers[question.order] === answer.id}
                    onChange={() => handleAnswerChange(question.order, answer.id)}
                  />
                  {answer.content}
                </label>
              ))
            ) : (
              // Hiển thị đáp án cho Part 1-4 (có thể chỉ có 3 đáp án)
              ["A", "B", "C", "D"].map((choice) => {
                const answer = answersForQuestion.find((ans) => ans.content.startsWith(choice));
                return (
                  answer && (
                    <label key={choice} className="choice-label">
                      <input
                        type="radio"
                        name={`question-${question.id}`}
                        checked={selectedAnswers[question.order] === answer.id}
                        onChange={() => handleAnswerChange(question.order, answer.id)}
                      />
                      
                    </label>
                  )
                );
              })
            )}
          </div>
        </div>
      );
    });
  };

  // Hiển thị toàn bộ câu hỏi (navigation bên phải)
  const renderAllQuestions = () => {
    return Object.entries(partsData).map(([part, { start, end }]) => (
      <div key={part} className="part-section">
        <h3>{part}</h3>
        <div className="question-numbers">
          {[...Array(end - start + 1)].map((_, i) => {
            const questionId = start + i;
            const isAnswered = Object.keys(selectedAnswers).includes(String(questionId));
            return (
              <button
                key={questionId}
                className={`question-number ${isAnswered ? "answered" : ""} ${
                  selectedPart === part && filteredQuestions.some((q) => q.id === questionId)
                    ? "active"
                    : ""
                }`}
                onClick={() => handleScrollToQuestion(questionId)}
              >
                {questionId}
              </button>
            );
          })}
        </div>
      </div>
    ));
  };

  const handleSubmit = () => {
    const confirm = window.confirm("Do you sure want to submit?");
    if (confirm) {
      navigate(`/test/result/${id}`);
    }
  }

  const handleExit = () =>{
    const confirm = window.confirm("Exit may not be saved!");
    if (confirm) {
      navigate('/');
    }
  }
  

  // Khi trang tải, load dữ liệu Part đầu tiên
  useEffect(() => {
    handlePartChange("Part 1");
  }, []);

  return (
    <div className="practice-page">
      <div className="practice-header">
        <h1>New Economy TOEIC Test 1</h1>
        <button onClick={handleExit} className="exit-button">
          Exit
        </button>
      </div>

      <div className="content-container">
        <div className="left-section">
          <div className="audio-controls">
            <label>
              <input type="checkbox" /> Highlight
            </label>
            <audio controls className="audio">
              {/* <source src="audio.mp3" type="audio/mpeg" /> */}
              <source src="https://s4-media1.study4.com/media/tez_media/sound/eco_toeic_1000_test_1_eco_toeic_1000_test_1.mp3" ></source>
            </audio>
          </div>

          <div className="part-tabs">
            {Object.entries(partsData).map(([part]) => (
              <button
                key={part}
                onClick={() => handlePartChange(part)}
                className={selectedPart === part ? "active" : ""}
              >
                {part}
              </button>
            ))}
          </div>

          <div className="question-content">{renderQuestions()}</div>
        </div>

        <div className="right-section">
          <div className="timer">
            <CountdownTimer />
            <button onClick={handleSubmit} className="submit-button">Submit</button>
          </div>

          <div className="question-nav">
            {renderAllQuestions()}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PracticePage;
