import React, { useState, useContext } from 'react';
import TestInfo from '../../components/TestDetail/TestInfo';
import PartSelection from '../../components/TestDetail/PartSelection';
import CommentsSection from '../../components/TestDetail/CommentsSection';
import TabNavigation from '../../components/TestDetail/TabNavigation';
import { MyContext } from '../../App';
import './TestDetailPage.css';
import { useNavigate, useParams } from 'react-router-dom';
import { Test, Part, TestPart, Group, Question, Answer } from '../../components/Data';


const TestDetailPage = () => {

  const [activeTab, setActiveTab] = useState('practice');
  const [selectedParts, setSelectedParts] = useState([]);
  const navigate = useNavigate();

  const {id} = useParams(); 

  const context = useContext(MyContext);

  const testInfo = Test.find(test => test.id === id);

  const parts = TestPart.filter(tp => tp.test_id === id)
    .map(tp => Part.find(p => p.id === tp.part_id))
    .map(part => ({
      id: part.id,
      name: part.title,
      questionCount: part.questionCount,
      selected: false
    }));


  const comments = [
    { id: 1, user: 'User1', text: 'Bài này khó quá!' },
    { id: 2, user: 'User2', text: 'Mình làm đúng 80% nè' },
    // Add more comments as needed
  ];

  const handlePartSelect = (id) => {
    const updatedParts = parts.map(part => 
      part.id === id ? { ...part, selected: !part.selected } : part
    );
    setSelectedParts(updatedParts);
  };

  const StartTest = () => {
    if(context.isLogin){
      navigate(`/fulltest/${id}`);
    }
    else {
      navigate('/login');
    }
  }

  return (
    <div className="test-details">
      <TestInfo {...testInfo} />
      <TabNavigation activeTab={activeTab} onTabChange={setActiveTab} />
      {activeTab === 'practice' && (
        <div>
            <PartSelection parts={parts} onSelect={handlePartSelect} />
            <div class="form-group">
            <label class="label" for="time_limit">Time Limit( Don't choose unless you want to set): </label>
            <select name="time_limit" class="custom-select ">
                <option value="" disabled="" selected="">-- Pick time --</option>
                <option value="0">0 </option>
                <option value="5">5 </option>
                <option value="10">10 </option>
                <option value="15">15 </option>
                <option value="20">20 </option>
                <option value="25">25 </option>
                <option value="30">30 </option>
                <option value="35">35 </option>
                <option value="40">40 </option>
                <option value="45">45 </option>
                <option value="50">50 </option>
                <option value="55">55 </option>
                <option value="60">60 </option>
                <option value="65">65 </option>
                <option value="70">70 </option>
                <option value="75">75 </option>
                <option value="80">80 </option>
                <option value="85">85 </option>
                <option value="90">90 </option>
                <option value="95">95 </option>
                <option value="100">100 </option>
                <option value="105">105 </option>
                <option value="110">110 </option>
                <option value="115">115 </option>
                <option value="120">120 </option>
                <option value="125">125 </option>
                <option value="130">130 </option>
                <option value="135">135 </option>
              </select>
              <span> minutes</span>
          </div>
            <button>Start Practice</button>
        </div>
      )}
      {activeTab === 'fullTest' && (
        <>
          <div className="note" >
            <i class="bi bi-calendar-x"></i>
            <span>  Ready to start full test? It took 120 mins to take this test.</span>
          </div>
          <button onClick={StartTest}>Start Test</button>
        </>
      )}
      {activeTab === 'discussion' && <CommentsSection comments={comments} />}
    </div>
  );
};

export default TestDetailPage;
