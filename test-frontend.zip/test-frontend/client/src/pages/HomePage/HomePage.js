// src/pages/HomePage.js
import React from 'react';
import Banner from '../../components/Banner/Banner';
import TestCard from '../../components/TestCard/TestCard';
import './HomePage.css';
import { useNavigate } from 'react-router-dom';
import {Test} from '../../components/Data';
const testData = Test;
console.log(testData);

const HomePage = () => {
    const navigate = useNavigate();
    return (
        <div className="home-page">
            <Banner />
            <h2>LASTEST TESTS</h2>
            <div className="test-list">
                {testData.map((test, index) => (
                    <TestCard
                        key={test.id}
                        title={test.title}
                        duration={test.duration}
                        questions={test.questions}
                        onClick={()=>navigate(`/detailtest/${test?.id}`)}
                        
                    />
                ))}
            </div>
        </div>
    );
};

export default HomePage;
