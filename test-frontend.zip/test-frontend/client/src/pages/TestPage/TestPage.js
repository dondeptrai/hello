import React, { useState } from 'react';
import Banner from '../../components/Banner/Banner';
import TestCard from '../../components/TestCard/TestCard';
import SearchBar from '../../components/SearchBar/SearchBar';
import './TestPage.css';
import { useNavigate } from 'react-router-dom';
import {Test} from '../../components/Data';

const testData = Test;


const TestsPage = () => {
    const [searchQuery, setSearchQuery] = useState('');
    const [filteredTests, setFilteredTests] = useState(testData);
    const navigate = useNavigate();

    const handleSearch = (query) => {
        setSearchQuery(query); // Cập nhật giá trị tìm kiếm
        const filtered = testData.filter(test => 
            test.title.toLowerCase().includes(query.toLowerCase())
        );
        setFilteredTests(filtered); // Lọc kết quả dựa trên giá trị tìm kiếm
    };

    const debounceSearch = (query) => {
        clearTimeout(window.debounceTimeout);
        window.debounceTimeout = setTimeout(() => {
            handleSearch(query);
        }, 500); // 500ms là thời gian chờ trước khi tìm kiếm
    };

    return (
        <div className="tests-page">
            <div className="left-section">
                <SearchBar onSearch={debounceSearch}/>
                <h2 className="section-title">ALL TOEIC TESTS</h2>
                <div className="test-list">
                    {filteredTests.map((test, index) => (
                        <TestCard
                            key={index}
                            title={test.title}
                            duration={test.duration}
                            questions={test.questions}
                            onClick={()=>navigate(`/detailtest/${test?.id}`)}
                        />
                    ))}
                </div>
            </div>
            <div className="right-section">
                <Banner />
            </div>
        </div>
    );
};

export default TestsPage;
