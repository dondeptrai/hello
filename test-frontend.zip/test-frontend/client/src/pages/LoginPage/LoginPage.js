import React, { useState, useContext } from 'react';
import { Link } from 'react-router-dom';
import './LoginPage.css';
import { useNavigate } from 'react-router-dom';
import { MyContext } from "../../App";

const LoginPage = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();
    const context = useContext(MyContext);
    const handleSubmit = async (e) => {
        e.preventDefault();

        // Gửi yêu cầu đăng nhập đến backend
        try {
            const response = await fetch('http://127.0.0.1:8000/login/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email, password }),
            });

            if (!response.ok) {
                const errorData = await response.json();
                setError(errorData.detail || 'Error ocurred!');
            } else {
                const res = await response.json();
                localStorage.setItem("token", res.token);

                const user = {
                    name: res.user?.name,
                    email: res.user?.email,
                    id: res.user?.id,
                }

                localStorage.setItem("user", JSON.stringify(user));
                context.setUser(JSON.stringify(user));
                setTimeout(() => {
                    navigate("/");
                    context.setIsLogin(true);
                  }, 300);
            }
        } catch (error) {
            setError('Cannot connect to server.');
            console.error(error);
        }
    };

    return (
        <div className="login-container">
            <div className="login-form">
                <h2>LOGIN</h2>
                <form onSubmit={handleSubmit}>
                    <div className="login-form-group">
                        <label>Email</label>
                        <input
                            type="email"
                            placeholder="Enter your email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            required
                        />
                    </div>
                    <div className="login-form-group">
                        <label>Password</label>
                        <input
                            type="password"
                            placeholder="Enter your password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            required
                        />
                    </div>
                    <button type="submit" className="login-button">Login</button>
                </form>
                
                {/* Hiển thị lỗi nếu có */}
                {error && <div className="error-message">{error}</div>}

                <p className="login-footer">
                    Don’t have an account? <Link to="/register">Register</Link>
                </p>
            </div>
        </div>
    );
};

export default LoginPage;
