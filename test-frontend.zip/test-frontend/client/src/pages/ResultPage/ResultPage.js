import React, {useEffect, useContext, useState} from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCheck,faPenToSquare,faClock,faCircleCheck,faCircleXmark,faCircleExclamation,faLightbulb } from '@fortawesome/free-solid-svg-icons';

import Banner from '../../components/Banner/Banner';
import QuestionDisplay from '../../components/Result/Result'
import './ResultPage.css';

const ResultPage = () => {
    const {id} = useParams();
    console.log(id);
    return (
        <div className='results-page'>
            <div className='left-section'>
                <h3>Result Of Test: {id}</h3>
                <button className='view-answer'>View Result</button>
                <button className='back-home'>Back to home</button>
                <div className='result-index'>
                    <div className='result-summary'>
                        <div className='icon-summary-text'>
                            <span><FontAwesomeIcon icon={faCheck} /></span>
                            <span>Result: </span>
                            <span>120/200</span>
                        </div>
                        <div className='icon-summary-text'>
                            <span><FontAwesomeIcon icon={faPenToSquare} /></span>
                            <span>Accuracy:</span>
                            <span>33%</span>
                        </div>
                        <div className='icon-summary-text'>
                            <span><FontAwesomeIcon icon={faClock} /></span>
                            <span>Time done:</span>
                            <span>0:0:0</span>
                        </div>
                    </div>
                    <div className='detail-index'>
                        <div className='icon-stat-text'>
                            <span><FontAwesomeIcon icon={faCircleCheck} size='2xl' style={{color: "#3eb151",}} /></span>
                            <span style={{color:'#3eb151'}}>Right answer</span>
                            <span>0</span>
                            <span>answer</span>
                        </div>
                        <div className='icon-stat-text'>
                            <span><FontAwesomeIcon icon={faCircleXmark} size='2xl' style={{color: "#ce3b3b",}} /></span>
                            <span style={{color:'#ce3b3b'}}>Wrong answer</span>
                            <span>0</span>
                            <span>answer</span>
                        </div>
                        <div className='icon-stat-text'>
                            <span><FontAwesomeIcon icon={faCircleExclamation} size='2xl' style={{color: "#616161",}} /></span>
                            <span style={{color:'#616161'}}>No answer</span>
                            <span>0</span>
                            <span>answer</span>
                        </div>
                    </div>
                </div>
                <h3>Solutions</h3>
                <button className='view-soluton'>Detail solutions</button><br/>
                <div className='icon-tip-text'>
                    <span><FontAwesomeIcon icon={faLightbulb} size="2xl" style={{color: "#74C0FC",}} /></span>
                    <span>  Click Detail solutions above to view all question and answer have done or view full choice below:</span>
                </div>
                <QuestionDisplay />
            </div>
            <div className='right-seciton'>
                <Banner />
            </div>
        </div>
    )
}

export default ResultPage;
