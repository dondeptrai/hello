import React,{useState} from "react";
import { useNavigate } from "react-router-dom";
import './RegisterPage.css';
import {Link} from 'react-router-dom';


const RegisterPage = () => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleSubmit = async(e) => {
        e.preventDefault();
        try{
            const response = await fetch('http://127.0.0.1:8000/register/',{
                method: 'POST',
                headers:{
                    'Content-Type':'application/json',
                },
                body: JSON.stringify({name, email, password}),
            })
            if(!response.ok){
                const errorData = await response.json();
                setError(errorData.detail || 'An error ocurred!');
            }
            else{
                const data = await response.json();
                setMessage('User registered successfully!');
                setError('');
                navigate('/login');
            }
        }
        catch (err){
             setError('Cannot connect to server!');
             console.error(err);
        }
    }


    return (
        <div className="register-container">
            <div className="register-form">
                <h2>REGISTER</h2>
                <form onSubmit={handleSubmit}>
                    <div className="register-form-group">
                        <label>Name</label>
                        <input 
                            type="text" 
                            placeholder="Enter your name"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            required
                            />
                        <label>Email</label>
                        <input 
                            type="email"
                            placeholder="Enter your email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            />
                        <label>Password</label>
                        <input 
                            type="password"
                            placeholder="Enter your password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            />
                        
                    </div>
                    <button type="submit" className="register-button">Regiter</button>
                </form>
                {message && <div className="success-message">{message}</div>}
                {error && <div className="error-message">{error}</div>}

                <p className="register-footer">
                    Already have an account? <Link to='/login'>Login</Link>
                </p>
            </div>
        </div>
    )
}


export default RegisterPage;