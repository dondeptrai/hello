import React, { useState, useEffect } from "react";

function CountdownTimer() {
  const [time, setTime] = useState(60 * 120); 

  useEffect(() => {
    if (time > 0) {
      const timer = setInterval(() => {
        setTime((prevTime) => prevTime - 1);
      }, 1000);
      return () => clearInterval(timer); 
    }
  }, [time]);

  const formatTime = (time) => {
    const minutes = Math.floor(time / 60);
    const seconds = time % 60;
    return `${minutes.toString().padStart(2, "0")}:${seconds
      .toString()
      .padStart(2, "0")}`;
  };

  return (
    <div>
      <p>
        Time: <span>{formatTime(time)}</span>
      </p>
    </div>
  );
}

export default CountdownTimer;
