import React from "react";

const Test = [
    {
      id: '1',
      title: "TOEIC Practice Test 1",
      duration: '120',
      questions: 200,
      description: "A full-length TOEIC practice test for learners to enhance their skills."
    },
    {
      id: '2',
      title: "TOEIC Practice Test 2",
      duration: '120',
      questions: 200,
      description: "Another practice test to boost your TOEIC skills."
    }
  ];


  const  Part = [
    { id: '1', part_order: 'Part 1', questionCount: 6, audio_url: "audio_part1.mp3", title: "Listening Part 1 - TOEIC Practice Test 1" },
    { id: '2', part_order: 'Part 2', questionCount: 25, audio_url: "audio_part2.mp3", title: "Listening Part 2 - TOEIC Practice Test 1" },
    { id: '3', part_order: 'Part 3', questionCount: 39, audio_url: "audio_part3.mp3", title: "Listening Part 3 - TOEIC Practice Test 1" },
    { id: '4', part_order: 'Part 4', questionCount: 25, audio_url: "audio_part4.mp3", title: "Listening Part 4 - TOEIC Practice Test 1" },
    { id: '5', part_order: 'Part 5', questionCount: 39,  audio_url: null, title: "Reading Part 5 - TOEIC Practice Test 1" },
    { id: '6', part_order: 'Part 6', questionCount: 25, audio_url: null, title: "Reading Part 6 - TOEIC Practice Test 1" },
    { id: '7', part_order: 'Part 7', questionCount: 39, audio_url: null, title: "Reading Part 7 - TOEIC Practice Test 1" }
  ];

  const  TestPart = [
    { id: '1',test_id: '1', part_id: '1' },
    { id: '2', test_id: '1', part_id: '2' },
    { id: '3', test_id: '1', part_id: '3' },
    { id: '4', test_id: '1', part_id: '4' },
    { id: '5', test_id: '1', part_id: '5' },
    { id: '6', test_id: '1', part_id: '6' },
    { id: '7', test_id: '1', part_id: '7' }
  ];

  const  Group = [
    { id: '1', paragraph1: "", paragraph2: null, image_url1: "https://study4.com/media/tez_media/img/eco_toeic_1000_test_1_eco_toeic_1000_test_1_1.png", image_url2: null },
    { id: '2', paragraph1: "", paragraph2: null, image_url1: "https://study4.com/media/tez_media/img/eco_toeic_1000_test_1_eco_toeic_1000_test_1_2.png", image_url2: null },
    { id: '3', paragraph1: "", paragraph2: "", image_url1: "https://study4.com/media/tez_media/img/eco_toeic_1000_test_1_eco_toeic_1000_test_1_3.png", image_url2: null },
    { id: '4', paragraph1: "", paragraph2: "", image_url1: null, image_url2: null },
    { id: '5', paragraph1: "", paragraph2: "", image_url1: null, image_url2: null },
    { id: '6', paragraph1: "", paragraph2: "", image_url1: null, image_url2: null },
    { id: '7', paragraph1: "", paragraph2: "", image_url1: null, image_url2: null },
    { id: '8', paragraph1: "", paragraph2: "", image_url1: null, image_url2: null },
    { id: '9', paragraph1: "", paragraph2: "", image_url1: null, image_url2: null },
    { id: '10', paragraph1: "", paragraph2: "", image_url1: null, image_url2: null },
    { id: '11', paragraph1: "", paragraph2: "", image_url1: null, image_url2: null },
    { id: '12', paragraph1: "", paragraph2: "", image_url1: null, image_url2: null },
    { id: '13', paragraph1: "", paragraph2: "", image_url1: null, image_url2: null },
    { id: '14', paragraph1: "", paragraph2: "", image_url1: null, image_url2: null },
    { id: '15', paragraph1: "", paragraph2: "", image_url1: null, image_url2: null },
    { id: '16', paragraph1: "", paragraph2: "", image_url1: null, image_url2: null },
    { id: '17', paragraph1: "", paragraph2: "", image_url1: null, image_url2: null },
    { id: '18', paragraph1: "", paragraph2: "", image_url1: null, image_url2: null },
    { id: '19', paragraph1: "", paragraph2: "", image_url1: null, image_url2: null },
    { id: '20', paragraph1: "", paragraph2: "", image_url1: null, image_url2: null },
    { id: '21', paragraph1: "", paragraph2: "", image_url1: null, image_url2: null },
    { id: '22', paragraph1: "", paragraph2: "", image_url1: null, image_url2: null },
    { id: '23', paragraph1: "", paragraph2: "", image_url1: null, image_url2: null },
    { id: '24', paragraph1: "This is a passage for questions 7-9.", paragraph2: "Follow-up paragraph.", image_url1: null, image_url2: null },
    { id: '25', paragraph1: "This is a passage for questions 7-9.", paragraph2: "Follow-up paragraph.", image_url1: null, image_url2: null },
    { id: '26', paragraph1: "This is a passage for questions 7-9.", paragraph2: "Follow-up paragraph.", image_url1: null, image_url2: null },
    { id: '27', paragraph1: "This is a passage for questions 7-9.", paragraph2: "Follow-up paragraph.", image_url1: null, image_url2: null },
    { id: '28', paragraph1: "This is a passage for questions 7-9.", paragraph2: "Follow-up paragraph.", image_url1: null, image_url2: null },
    { id: '29', paragraph1: "This is a passage for questions 7-9.", paragraph2: "Follow-up paragraph.", image_url1: null, image_url2: null },
    { id: '30', paragraph1: "This is a passage for questions 7-9.", paragraph2: "Follow-up paragraph.", image_url1: null, image_url2: null },
    { id: '31', paragraph1: "This is a passage for questions 7-9.", paragraph2: "Follow-up paragraph.", image_url1: null, image_url2: null },
    { id: '32', paragraph1: "This is a passage for questions 7-9.", paragraph2: "Follow-up paragraph.", image_url1: "https://study4.com/media/tez_media/img/eco_toeic_1000_test_1_eco_toeic_1000_test_1_1.png", image_url2: 'https://study4.com/media/tez_media/img/eco_toeic_1000_test_1_eco_toeic_1000_test_1_2.png' },
  ];

  const Question = [
    { id: '1', part_id: '1', order: '1', content: "", group_id: "1"  },
    { id: '2', part_id: '1', order: '2', content: "", group_id: "2"  },
    { id: '3', part_id: '1', order: '3', content: "", group_id: "3"  },
    { id: '4', part_id: '2', order: '7', content: "Where was the company picnic held?", group_id: "4"  },
    { id: '5', part_id: '2', order: '8', content: "Who's working at the front desk today?", group_id: "5"  },
    { id: '6', part_id: '2', order: '9', content: "Would you like to work together or separately?", group_id: "6"  },
    // Part 2 questions (30 questions)
    { id: '7', part_id: '3', order: '32', content: "How much does this item cost?", group_id: "7" },
    { id: '8', part_id: '3', order: '33', content: "Where is the meeting scheduled?", group_id: "8" },
    { id: '9', part_id: '3', order: '34', content: "When will the project be completed?", group_id: "9" },
    { id: '10', part_id: '3', order: '62', content: "What does the woman have on Friday?", group_id: "10" },
    { id: '11', part_id: '3', order: '63', content: "Look at the graphic. How much does the woman pay for the furniture?", group_id: "10" },
    { id: '12', part_id: '3', order: '64', content: "What does the man say he will do?", group_id: "10" },
    { id: '13', part_id: '4', order: '71', content: "How can I contact customer service?", group_id: "11" },
    { id: '14', part_id: '4', order: '72', content: "Where should I send the application?", group_id: "12" },
    { id: '15', part_id: '4', order: '73', content: "When will the new software be available?", group_id: "13" },
    { id: '16', part_id: '4', order: '92', content: "Look at the graphic. Which items need to be ordered?", group_id: "14" },
    { id: '17', part_id: '4', order: '93', content: "What does the speaker anticipate about the company?", group_id: "14" },
    { id: '18', part_id: '4', order: '94', content: "What is the listener asked to do before making any orders?", group_id: "14" },
    { id: '19', part_id: '5', order: '101', content: "When filling out the order form, please _____ your address clearly to prevent delays.", group_id: "15" },
    { id: '20', part_id: '5', order: '102', content: "Ms. Morgan recruited the individuals that the company _____ for the next three months.", group_id: "16" },
    { id: '21', part_id: '5', order: '103', content: "The contractor had a fifteen-percent _____ in his business after advertising in the local newspaper.", group_id: "17" },
    { id: '22', part_id: '5', order: '104', content: "The free clinic was founded by a group of doctors to give _____ for various medical conditions.", group_id: "18" },
    { id: '23', part_id: '5', order: '105', content: "Participants in the walking tour should gather _____ 533 Bates Road on Saturday morning.", group_id: "19" },
    { id: '24', part_id: '5', order: '106', content: "The artist sent _____ best pieces to the gallery to be reviewed by the owner.", group_id: "20" },
    { id: '25', part_id: '5', order: '107', content: "The figures that accompany the financial statement should be _____ to the spending category.", group_id: "21" },
    { id: '26', part_id: '5', order: '108', content: "The building owner purchased the property _____ three months ago, but she has already spent a great deal of money on renovations.", group_id: "22" },
    { id: '27', part_id: '5', order: '109', content: "We would like to discuss this problem honestly and _____ at the next staff meeting.", group_id: "23" },
    { id: '28', part_id: '6', order: '131', content: "(131)", group_id: "24" },
    { id: '29', part_id: '6', order: '132', content: "(132)", group_id: "24" },
    { id: '30', part_id: '6', order: '133', content: "(133)", group_id: "24" },
    { id: '31', part_id: '6', order: '134', content: "(134)", group_id: "24" },
    { id: '32', part_id: '6', order: '135', content: "(135)", group_id: "25" },
    { id: '33', part_id: '6', order: '136', content: "(136)", group_id: "25" },
    { id: '34', part_id: '6', order: '137', content: "(137)", group_id: "25" },
    { id: '35', part_id: '6', order: '138', content: "(138)", group_id: "25" },
    { id: '36', part_id: '7', order: '147', content: "What is indicated about the seminar??", group_id: "26" },
    { id: '37', part_id: '7', order: '148', content: "When will the free registration offer end?", group_id: "26" },
    { id: '38', part_id: '7', order: '149', content: "Where most likely is Nancy?", group_id: "27" },
    { id: '39', part_id: '7', order: '150', content: "What did Nancy mean when she said 'I'm headed there now'?", group_id: "27" },
    { id: '40', part_id: '7', order: '155', content: "What is indicated about the old courthouse?", group_id: "28" },
    { id: '41', part_id: '7', order: '156', content: "In which of the positions marked [1], [2], [3] and [4] does the following sentence belong? 'Branford Construction, the development company that originally planned to build the shopping mall, is looking to build the mall outside of the Rivervalley Community.'", group_id: "28" },
    { id: '42', part_id: '7', order: '157', content: "What is suggested about the fundraising efforts?", group_id: "28" },
    { id: '43', part_id: '7', order: '161', content: "What kind of business do the online speakers work at?", group_id: "29" },
    { id: '44', part_id: '7', order: '162', content: "When will the crew begin work?", group_id: "29" },
    { id: '45', part_id: '7', order: '163', content: "What will Johnny Jordan probably do next?", group_id: "29" },
    { id: '46', part_id: '7', order: '164', content: "What does Monica Stein mean by 'I'm on it'?", group_id: "29" },
    { id: '47', part_id: '7', order: '176', content: "Who most likely is the lecture series intended for?", group_id: "30" },
    { id: '48', part_id: '7', order: '177', content: "In the brochure, the word 'through' is closest in meaning to", group_id: "30" },
    { id: '49', part_id: '7', order: '178', content: "What most likely will be discussed at the lecture on February 10?", group_id: "30" },
    { id: '50', part_id: '7', order: '179', content: "According to Mr. Patterson, whose lecture must be rescheduled?", group_id: "30" },
    { id: '51', part_id: '7', order: '180', content: "What is Ms. Flores instructed to do on a website?", group_id: "30" },
    { id: '52', part_id: '7', order: '186', content: "What is the purpose of the first e-mail?", group_id: "31" },
    { id: '53', part_id: '7', order: '187', content: "What package option most likely fits Ms. Hall's needs best?", group_id: "31" },
    { id: '54', part_id: '7', order: '188', content: "What information is not needed for a final price?", group_id: "31" },
    { id: '55', part_id: '7', order: '189', content: "What is indicated in Emily Hall's e-mail?", group_id: "31" },
    { id: '56', part_id: '7', order: '190', content: "Why does Emily Hall want to know about the vegetables that will be available throughout the year?", group_id: "31" },
    { id: '57', part_id: '7', order: '196', content: "Why was the inspection conducted?", group_id: "32" },
    { id: '58', part_id: '7', order: '197', content: "Why has Polito's Pizza been charged a fine?", group_id: "32" },
    { id: '59', part_id: '7', order: '198', content: "What does Mr. Kluck ask his employees to do?", group_id: "32" },
    { id: '60', part_id: '7', order: '199', content: "What will happen if an employee fails to sign the work checklist?", group_id: "32" },
    { id: '61', part_id: '7', order: '200', content: "Based on Polito's Checklist, what can we infer about K.P.?", group_id: "32" },
  ];
  
  const Answer = [
    {id: '1', question_id: '1', content: "A. ", is_correct: true },
    { id: '2', question_id: '1', content: "B.", is_correct: false },
    { id: '3', question_id: '1', content: "C. ", is_correct: false },
    { id: '4', question_id: '1', content: "D. ", is_correct: false },

    {id: '5', question_id: '2', content: "A. ", is_correct: true },
    { id: '6', question_id: '2', content: "B.", is_correct: false },
    { id: '7', question_id: '2', content: "C. ", is_correct: false },
    { id: '8', question_id: '2', content: "D. ", is_correct: false },

    {id: '9', question_id: '3', content: "A. ", is_correct: true },
    { id: '10', question_id: '3', content: "B.", is_correct: false },
    { id: '11', question_id: '3', content: "C. ", is_correct: false },
    { id: '12', question_id: '3', content: "D. ", is_correct: false },

    {id: '13', question_id: '4', content: "A. ", is_correct: false },
    { id: '14', question_id: '4', content: "B.", is_correct: false },
    { id: '15', question_id: '4', content: "C. ", is_correct: true },

    {id: '16', question_id: '5', content: "A. ", is_correct: false },
    { id: '17', question_id: '5', content: "B.", is_correct: true },
    { id: '18', question_id: '5', content: "C. ", is_correct: false },

    {id: '19', question_id: '6', content: "A. ", is_correct: true },
    { id: '20', question_id: '6', content: "B.", is_correct: false },
    { id: '21', question_id: '6', content: "C. ", is_correct: false },

    {id: '22', question_id: '7', content: "A. training seminar. ", is_correct: false },
    { id: '23', question_id: '7', content: "B.  The installation of a television.", is_correct: true },
    { id: '24', question_id: '7', content: "C. The date of a presentation.", is_correct: false },
    { id: '25', question_id: '7', content: "D. A software upgrade.", is_correct: false },

    {id: '26', question_id: '8', content: "A. The necessary tools are unavailable. ", is_correct: true },
    { id: '27', question_id: '8', content: "B. The office is closed.", is_correct: false },
    { id: '28', question_id: '8', content: "C. The wall is too weak.", is_correct: false },
    { id: '29', question_id: '8', content: "D. The phone number was wrong.", is_correct: false },

    {id: '30', question_id: '9', content: "A. Order a replacement part. ", is_correct: false },
    { id: '31', question_id: '9', content: "B.  Consult an instruction manual.", is_correct: false },
    { id: '32', question_id: '9', content: "C. Contact the woman.", is_correct: true },
    { id: '33', question_id: '9', content: "D. Fill out a work order.", is_correct: false },

    {id: '34', question_id: '10', content: "A. A dinner meeting.", is_correct: false },
    { id: '35', question_id: '10', content: "B.  A seminar.", is_correct: false },
    { id: '36', question_id: '10', content: "C. A meeting.", is_correct: true },
    { id: '37', question_id: '10', content: "D. A work party.", is_correct: false },

    {id: '38', question_id: '11', content: "A. $165", is_correct: false },
    { id: '39', question_id: '11', content: "B.  $195.", is_correct: false },
    { id: '40', question_id: '11', content: "C. $307.", is_correct: false },
    { id: '41', question_id: '11', content: "D. $614.", is_correct: true },

    {id: '42', question_id: '12', content: "A.  Arrange free delivery. ", is_correct: true },
    { id: '43', question_id: '12', content: "B.  Deliver the furniture in the evening.", is_correct: false },
    { id: '44', question_id: '12', content: "C.  Send a confirmation.", is_correct: false },
    { id: '45', question_id: '12', content: "D.Deliver the table himself.", is_correct: false },

    
    {id: '46', question_id: '13', content: "A. At a theater.", is_correct: false },
    { id: '47', question_id: '13', content: "B. At a car dealership", is_correct: false },
    { id: '48', question_id: '13', content: "C.  At a retail store.", is_correct: true },
    { id: '49', question_id: '13', content: "D. At a library.", is_correct: false },
    
    {id: '50', question_id: '14', content: "A. Accurate prices.", is_correct: true },
    { id: '51', question_id: '14', content: "B.Sales figures.", is_correct: false },
    { id: '52', question_id: '14', content: "C.Business hours. ", is_correct: false },
    { id: '53', question_id: '14', content: "D. Name tags.", is_correct: false },
    
    {id: '54', question_id: '15', content: "A. If an employee is late for work.", is_correct: false },
    { id: '55', question_id: '15', content: "B.If an employee is late for work.", is_correct: false },
    { id: '56', question_id: '15', content: "C.  If an item is out of stock.", is_correct: false },
    { id: '57', question_id: '15', content: "D. If a customer is dissatisfied.", is_correct: true },
    
    {id: '58', question_id: '16', content: "A. Office tables and chairs.", is_correct: false },
    { id: '59', question_id: '16', content: "B. Chairs and drafting tables.", is_correct: false },
    { id: '60', question_id: '16', content: "C. Whiteboards and office chairs.", is_correct: true },
    { id: '61', question_id: '16', content: "D. Chairs and whiteboard.", is_correct: false },
    
    {id: '62', question_id: '17', content: "A. They won't need any more furniture.", is_correct: false },
    { id: '63', question_id: '17', content: "B.They will have more staff in their building.", is_correct: true },
    { id: '64', question_id: '17', content: "C. The boardrooms will be renovated.", is_correct: false },
    { id: '65', question_id: '17', content: "D. Their staff are moving offices.", is_correct: false },
    
    {id: '1', question_id: '18', content: "A. Sign them herself.", is_correct: false },
    { id: '2', question_id: '18', content: "B.Make sure the manager signs them.", is_correct: true },
    { id: '3', question_id: '18', content: "C.Bring some extra paper.", is_correct: false },
    { id: '4', question_id: '18', content: "D. Prepare a delivery receipt.", is_correct: false },

    
    {id: '1', question_id: '19', content: "A. fix", is_correct: false },
    { id: '2', question_id: '19', content: "B. write", is_correct: true },
    { id: '3', question_id: '19', content: "C.  send", is_correct: false },
    { id: '4', question_id: '19', content: "D. direct", is_correct: false },
    
    {id: '1', question_id: '20', content: "A. will employ", is_correct: true },
    { id: '2', question_id: '20', content: "B. to employ", is_correct: false },
    { id: '3', question_id: '20', content: "C.  has been employed", is_correct: false },
    { id: '4', question_id: '20', content: "D. employ", is_correct: false },
    
    {id: '1', question_id: '21', content: "A. experience", is_correct: false },
    { id: '2', question_id: '21', content: "B. growth", is_correct: true },
    { id: '3', question_id: '21', content: "C. formula", is_correct: false },
    { id: '4', question_id: '21', content: "D. incentive", is_correct: false },
    
    {id: '1', question_id: '22', content: "A. treatment", is_correct: true },
    { id: '2', question_id: '22', content: "B.treat", is_correct: false },
    { id: '3', question_id: '22', content: "C.  treated", is_correct: false },
    { id: '4', question_id: '22', content: "D. treating", is_correct: false },
    
    {id: '1', question_id: '23', content: "A.with", is_correct: false },
    { id: '2', question_id: '23', content: "B.at", is_correct: true },
    { id: '3', question_id: '23', content: "C.like", is_correct: false },
    { id: '4', question_id: '23', content: "D.among", is_correct: false },
    
    {id: '1', question_id: '24', content: "A.him", is_correct: false },
    { id: '2', question_id: '24', content: "B. himself", is_correct: false },
    { id: '3', question_id: '24', content: "C. his", is_correct: true },
    { id: '4', question_id: '24', content: "D. he.", is_correct: false },
    
    {id: '1', question_id: '25', content: "A.relevance", is_correct: false },
    { id: '2', question_id: '25', content: "B. relevantly", is_correct: false },
    { id: '3', question_id: '25', content: "C. more relevantly", is_correct: false },
    { id: '4', question_id: '25', content: "D.relevant", is_correct: true },
    
    {id: '1', question_id: '26', content: "A. yes", is_correct: false },
    { id: '2', question_id: '26', content: "B. just", is_correct: true },
    { id: '3', question_id: '26', content: "C. feww", is_correct: false },
    { id: '4', question_id: '26', content: "D. still", is_correct: false },
    
    {id: '1', question_id: '27', content: "A. rarely", is_correct: false },
    { id: '2', question_id: '27', content: "B. tiredly", is_correct: false },
    { id: '3', question_id: '27', content: "C.  openly", is_correct: true },
    { id: '4', question_id: '27', content: "D.highly", is_correct: false },
    
    {id: '1', question_id: '28', content: "A. seek", is_correct: false },
    { id: '2', question_id: '28', content: "B. to seek", is_correct: false },
    { id: '3', question_id: '28', content: "C. seeking", is_correct: true },
    { id: '4', question_id: '28', content: "D. are seeking", is_correct: false },
    
    {id: '1', question_id: '29', content: "A. extensive", is_correct: true },
    { id: '2', question_id: '29', content: "B.restricted", is_correct: false },
    { id: '3', question_id: '29', content: "C. generous", is_correct: false },
    { id: '4', question_id: '29', content: "D. limitless", is_correct: false },
    
    {id: '1', question_id: '30', content: "A. I would really appreciate the opportunity to work with you.", is_correct: false },
    { id: '2', question_id: '30', content: "B.I heard that DigitalIT is a great company.", is_correct: false },
    { id: '3', question_id: '30', content: "C. In fact, our designs are often copied by other companies.", is_correct: false },
    { id: '4', question_id: '30', content: "D.  I have attached a number of our past designs to illustrate what we specialize in.", is_correct: true },
    
    {id: '1', question_id: '31', content: "A. at", is_correct: false },
    { id: '2', question_id: '31', content: "B.to", is_correct: true },
    { id: '3', question_id: '31', content: "C. with", is_correct: false },
    { id: '4', question_id: '31', content: "D. from", is_correct: false },
    
    {id: '1', question_id: '32', content: "A. durable", is_correct: false },
    { id: '2', question_id: '32', content: "B.durability", is_correct: true },
    { id: '3', question_id: '32', content: "C. duration", is_correct: false },
    { id: '4', question_id: '32', content: "D. during", is_correct: false },
    
    {id: '1', question_id: '33', content: "A. Larson's utensils and silverware go great with the dinnerware.", is_correct: false },
    { id: '2', question_id: '33', content: "B. Our most popular line, the Spring Flower China is sold out at most locations.", is_correct: false },
    { id: '3', question_id: '33', content: "C. Visit our store to check out our other beautiful products.", is_correct: false },
    { id: '4', question_id: '33', content: "D. They are dishwasher- and microwave-safe and we're confident that you'll be using them for years to come.", is_correct: true },
    
    {id: '1', question_id: '34', content: "A. result in", is_correct: true },
    { id: '2', question_id: '34', content: "B.occur to", is_correct: false },
    { id: '3', question_id: '34', content: "C. ending at", is_correct: false },
    { id: '4', question_id: '34', content: "D.  stop with", is_correct: false },
    
    {id: '1', question_id: '35', content: "A. ambitious", is_correct: false },
    { id: '2', question_id: '35', content: "B.combative", is_correct: false },
    { id: '3', question_id: '35', content: "C. aggressive", is_correct: true },
    { id: '4', question_id: '35', content: "D. complacent", is_correct: false },
    
    {id: '1', question_id: '36', content: "A. It will feature speaker James Taylor.", is_correct: false },
    { id: '2', question_id: '36', content: "B.It is held annually ", is_correct: false },
    { id: '3', question_id: '36', content: "C. Its fee is more expensive than the last one.", is_correct: false },
    { id: '4', question_id: '36', content: "D. It is designed for women.", is_correct: true },
    
    {id: '1', question_id: '37', content: "A. On February 5", is_correct: false },
    { id: '2', question_id: '37', content: "B.On February 12", is_correct: true },
    { id: '3', question_id: '37', content: "C. On February 21", is_correct: false },
    { id: '4', question_id: '37', content: "D. On February 23", is_correct: false },
    
    {id: '1', question_id: '38', content: "A. At a conference room", is_correct: false },
    { id: '2', question_id: '38', content: "B.At the IT department", is_correct: false },
    { id: '3', question_id: '38', content: "C.In the supply room ", is_correct: true },
    { id: '4', question_id: '38', content: "D. In her office", is_correct: false },
    
    {id: '1', question_id: '39', content: "A. She was going to the location.", is_correct: true },
    { id: '2', question_id: '39', content: "B.She would lead the presentation.", is_correct: false },
    { id: '3', question_id: '39', content: "C. She knew where the room was.", is_correct: false },
    { id: '4', question_id: '39', content: "D. She was going straight to meet him.", is_correct: false },
    
    {id: '1', question_id: '40', content: "A. Branford Construction wants to renovate the building.", is_correct: false },
    { id: '2', question_id: '40', content: "B.SThe residents want to turn the building into a shopping mall.", is_correct: false },
    { id: '3', question_id: '40', content: "C.  It may become a public library or school.", is_correct: true },
    { id: '4', question_id: '40', content: "D. It may be destroyed.", is_correct: false },
    
    {id: '1', question_id: '41', content: "A. [1]", is_correct: true },
    { id: '2', question_id: '41', content: "B.[2]", is_correct: false },
    { id: '3', question_id: '41', content: "C.[3] ", is_correct: false },
    { id: '4', question_id: '41', content: "D.[4] ", is_correct: false },
    
    {id: '1', question_id: '42', content: "A. The community made a lot of money from the land. ", is_correct: false },
    { id: '2', question_id: '42', content: "B.It has been occuring online.", is_correct: true },
    { id: '3', question_id: '42', content: "C. The city government has been helping.", is_correct: false },
    { id: '4', question_id: '42', content: "D. They haven't raised enough money.", is_correct: false },
    
    {id: '1', question_id: '43', content: "A. A law firm", is_correct: false },
    { id: '2', question_id: '43', content: "B.An office supply company", is_correct: true },
    { id: '3', question_id: '43', content: "C. A furniture shop ", is_correct: false },
    { id: '4', question_id: '43', content: "D. A moving company", is_correct: false },
    
    {id: '1', question_id: '44', content: "A. Tuesday", is_correct: false },
    { id: '2', question_id: '44', content: "B.Wednesday", is_correct: false },
    { id: '3', question_id: '44', content: "C. Thursday", is_correct: true },
    { id: '4', question_id: '44', content: "D. Friday", is_correct: false },
    
    {id: '1', question_id: '45', content: "A. Contact the distributors", is_correct: false },
    { id: '2', question_id: '45', content: "B.Organize a meeting", is_correct: false },
    { id: '3', question_id: '45', content: "C. Gather a large crew ", is_correct: true },
    { id: '4', question_id: '45', content: "D. Call the client", is_correct: false },
    
    {id: '1', question_id: '46', content: "A. She'll organize the movers.", is_correct: false },
    { id: '2', question_id: '46', content: "B.She'll wait until she gets more", is_correct: false },
    { id: '3', question_id: '46', content: "C. She'll visit the manufacturers.", is_correct: false },
    { id: '4', question_id: '46', content: "D.  She'll contact the client.", is_correct: true },
    
    {id: '1', question_id: '47', content: "A. Community members", is_correct: true },
    { id: '2', question_id: '47', content: "B.Building superintendents", is_correct: false },
    { id: '3', question_id: '47', content: "C.University professors ", is_correct: false },
    { id: '4', question_id: '47', content: "D. Hospital patients", is_correct: false },
    
    {id: '1', question_id: '48', content: "A. over", is_correct: false },
    { id: '2', question_id: '48', content: "B.via", is_correct: true },
    { id: '3', question_id: '48', content: "C. across", is_correct: false },
    { id: '4', question_id: '48', content: "D. until", is_correct: false },
    
    {id: '1', question_id: '49', content: "A.  How to balance yearly budgets", is_correct: false },
    { id: '2', question_id: '49', content: "B.How to meet infrastructure needs", is_correct: false },
    { id: '3', question_id: '49', content: "C. How to avoid environmental damage", is_correct: true },
    { id: '4', question_id: '49', content: "D. How to stimulate economic development", is_correct: false },
    
    {id: '1', question_id: '50', content: "A. Mr. Watson's", is_correct: false },
    { id: '2', question_id: '50', content: "B.Mr. Ross's", is_correct: false },
    { id: '3', question_id: '50', content: "C. Ms. Simmons's", is_correct: true },
    { id: '4', question_id: '50', content: "D.  Mr. Powell's", is_correct: false },
    
    {id: '1', question_id: '51', content: "A. Download a document", is_correct: false },
    { id: '2', question_id: '51', content: "B.Change a room reservation", is_correct: true },
    { id: '3', question_id: '51', content: "C.Update personal information ", is_correct: false },
    { id: '4', question_id: '51', content: "D. Facilitate a forum", is_correct: false },

    {id: '1', question_id: '52', content: "A. To request cost information", is_correct: true },
    { id: '2', question_id: '52', content: "B.To inquire about a policy change", is_correct: false },
    { id: '3', question_id: '52', content: "C. To postpone an order", is_correct: false },
    { id: '4', question_id: '52', content: "D. To report an incorrect invoice", is_correct: false },
    
    {id: '1', question_id: '53', content: "A. Personal", is_correct: false },
    { id: '2', question_id: '53', content: "B.Small", is_correct: true },
    { id: '3', question_id: '53', content: "C. Medium", is_correct: false },
    { id: '4', question_id: '53', content: "D. Large", is_correct: false },
    
    {id: '1', question_id: '54', content: "A.  Length of contract", is_correct: false },
    { id: '2', question_id: '54', content: "B.Method of delivery", is_correct: false },
    { id: '3', question_id: '54', content: "C. Additional items", is_correct: false },
    { id: '4', question_id: '54', content: "D. Distance of shipping", is_correct: true },
    
    {id: '1', question_id: '55', content: "A. She wants to try it for a month.", is_correct: false },
    { id: '2', question_id: '55', content: "B.She wants the free gift.", is_correct: false },
    { id: '3', question_id: '55', content: "C. She is interested in a long-term contract.", is_correct: true },
    { id: '4', question_id: '55', content: "D. She doesn't want winter produce.", is_correct: false },
    
    {id: '1', question_id: '56', content: "A.  She loves vegetables.", is_correct: false },
    { id: '2', question_id: '56', content: "B.She is thinking about adding meat.", is_correct: false },
    { id: '3', question_id: '56', content: "C. She might hire another employee.", is_correct: false },
    { id: '4', question_id: '56', content: "D.  She wants to plan her future menus.", is_correct: true },
    
    {id: '1', question_id: '57', content: "A.  To monitor compliance with food industry regulations", is_correct: true },
    { id: '2', question_id: '57', content: "B.To rate the taste and quality of the cuisine", is_correct: false },
    { id: '3', question_id: '57', content: "C. To inspect the structural safety of the building", is_correct: false },
    { id: '4', question_id: '57', content: "D. To evaluate the effectiveness of new policies", is_correct: false },
    
    {id: '1', question_id: '58', content: "A. Because fire extinguishers were not in place.", is_correct: false },
    { id: '2', question_id: '58', content: "B.Because containers of food were not marked appropriately.", is_correct: true },
    { id: '3', question_id: '58', content: "C. Because raw meats and vegetables were handled incorrectly.", is_correct: false },
    { id: '4', question_id: '58', content: "D. Because the facilities were not cleaned according to standards.", is_correct: false },
    
    {id: '1', question_id: '59', content: "A.  Apologize to customers", is_correct: false },
    { id: '2', question_id: '59', content: "B.Wear a name tag at all times", is_correct: false },
    { id: '3', question_id: '59', content: "C.File a complaint with Ms. Tenner ", is_correct: false },
    { id: '4', question_id: '59', content: "D.  Fill out a required form", is_correct: true },
    
    {id: '1', question_id: '60', content: "A. They will have a violation on their record.", is_correct: true },
    { id: '2', question_id: '60', content: "B.They will have to pay a fine.", is_correct: false },
    { id: '3', question_id: '60', content: "C. They will have to come in on the weekends.", is_correct: false },
    { id: '4', question_id: '60', content: "D. They will be fired.", is_correct: false },
    
    {id: '1', question_id: '61', content: "A. He works at night.", is_correct: false },
    { id: '2', question_id: '61', content: "B.He did not work on Thursday and Friday.", is_correct: true },
    { id: '3', question_id: '61', content: "C.He will be fired for violations. ", is_correct: false },
    { id: '4', question_id: '61', content: "D.He is slow at work. ", is_correct: false },
    
    
  ];

  export { Test, Part, TestPart, Group, Question, Answer };
    
  
  
  