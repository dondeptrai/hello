// src/components/Header.js
import React, {useContext ,useState, useEffect} from 'react';
import { Link } from 'react-router-dom';
import './Header.css';
import Logo from '../../assets/logo-removebg-preview.png';
import { MyContext } from '../../App';


const Header = () => {
    const [isScrolled, setIsScrolled] = useState(false);
    const handleScroll = () => {
        if (window.scrollY > 60) {
            setIsScrolled(true); // Khi cuộn xuống hơn 50px
        } else {
            setIsScrolled(false); // Khi ở gần đầu trang
        }
    };

    useEffect(() => {
        window.addEventListener("scroll", handleScroll);
        return () => {
            window.removeEventListener("scroll", handleScroll);
        };
    }, []);

    const changeLogin = () => {
        localStorage.removeItem("user");
        localStorage.removeItem("token");
        context.setIsLogin(false);
    }

    const context = useContext(MyContext);
    return (
        <header className={`header ${isScrolled ? "small" : "large"}`}>
            <div class="logo">
                <Link to="/"><img src={Logo} alt="Logo" /></Link>
            </div>
            <nav>
                <Link to="/">Home</Link>
                <Link to="/test">Tests</Link>
                {context.isLogin === true ? 
                <Link to="/" onClick={changeLogin}>Logout</Link> : <Link to="/login">Login</Link>}
                
            </nav>
        </header>
    );
};

export default Header;
