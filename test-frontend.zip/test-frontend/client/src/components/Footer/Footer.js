// src/components/Footer.js

import React from 'react';
import './Footer.css';
import Logo from '../../assets/logo-removebg-preview.png'

// Replace these with actual social media icons
import { FaFacebook, FaTwitter, FaInstagram, FaYoutube } from 'react-icons/fa';

const Footer = () => {
    return (
        <footer className="footer">
            <div className="footer-content">
                <div className="footer-logo-section">
                    <img src={Logo} alt="Logo" className="footer-logo"/>
                    <p className="footer-description">
                        The best platform to practice and prepare for TOEIC exams with unlimited access to resources.
                    </p>
                </div>
                
                <div className="footer-social-section">
                    <h3>Follow Us</h3>
                    <div className="social-icons">
                        <a href="https://facebook.com" target="_blank" rel="noopener noreferrer">
                            <FaFacebook className="social-icon" />
                        </a>
                        <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">
                            <FaTwitter className="social-icon" />
                        </a>
                        <a href="https://instagram.com" target="_blank" rel="noopener noreferrer">
                            <FaInstagram className="social-icon" />
                        </a>
                        <a href="https://youtube.com" target="_blank" rel="noopener noreferrer">
                            <FaYoutube className="social-icon" />
                        </a>
                    </div>
                </div>
            </div>

            <div className="footer-bottom">
                <p>© 2024 TOEIC Practice. All rights reserved.</p>
            </div>
        </footer>
    );
};

export default Footer;
