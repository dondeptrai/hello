import React from "react";
import "./Result.css";

const fakeData = [
  {
    part: 1,
    questions: Array.from({ length: 6 }, (_, i) => ({
      id: i + 1,
      correctAnswer: "A",
      userAnswer: i % 2 === 0 ? "A" : "B",
    })),
  },
  {
    part: 2,
    questions: Array.from({ length: 25 }, (_, i) => ({
      id: i + 7,
      correctAnswer: "B",
      userAnswer: i % 2 === 0 ? "B" : "C",
    })),
  },
  {
    part: 3,
    questions: Array.from({ length: 39 }, (_, i) => ({
      id: i + 32,
      correctAnswer: "C",
      userAnswer: i % 3 === 0 ? "C" : "D",
    })),
  },
  {
    part: 4,
    questions: Array.from({ length: 30 }, (_, i) => ({
      id: i + 71,
      correctAnswer: "D",
      userAnswer: i % 4 === 0 ? "D" : "A",
    })),
  },
  {
    part: 5,
    questions: Array.from({ length: 30 }, (_, i) => ({
      id: i + 101,
      correctAnswer: "A",
      userAnswer: i % 2 === 0 ? "A" : "B",
    })),
  },
  {
    part: 6,
    questions: Array.from({ length: 16 }, (_, i) => ({
      id: i + 131,
      correctAnswer: "B",
      userAnswer: i % 2 === 0 ? "B" : "C",
    })),
  },
  {
    part: 7,
    questions: Array.from({ length: 54 }, (_, i) => ({
      id: i + 147,
      correctAnswer: "C",
      userAnswer: i % 3 === 0 ? "C" : "D",
    })),
  },
];

const QuestionDisplay = () => {
  return (
    <div className="question-display">
      <h1>Danh sách câu hỏi</h1>
      {fakeData.map((part) => (
        <div key={part.part} className="part-section">
          <h2>Part {part.part}</h2>
          <div className="question-container">
            {/* Chia đôi câu hỏi */}
            <div className="column">
              {part.questions
                .slice(0, Math.ceil(part.questions.length / 2))
                .map((question, idx) => (
                  <div key={idx} className="question-item">
                    {question.id}. {question.correctAnswer} : {question.userAnswer}{" "}
                    <a href="#" className="detail-link">
                      Chi tiết
                    </a>
                  </div>
                ))}
            </div>
            <div className="column">
              {part.questions
                .slice(Math.ceil(part.questions.length / 2))
                .map((question, idx) => (
                  <div key={idx} className="question-item">
                    {question.id}. {question.correctAnswer} : {question.userAnswer}{" "}
                    <a href="#" className="detail-link">
                      Chi tiết
                    </a>
                  </div>
                ))}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default QuestionDisplay;
