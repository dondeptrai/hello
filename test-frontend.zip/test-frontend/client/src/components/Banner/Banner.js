// src/components/Banner.js
import React from 'react';
import './Banner.css';

const Banner = () => {
    return (
        <div className="banner">
            <h2>Practice IELTS, TOEIC without limits</h2>
            <p>Access unlimited tests and track your progress with ease.</p>
            <button>Explore Tests</button>
        </div>
    );
};

export default Banner;
