import React from 'react';

const TabNavigation = ({ activeTab, onTabChange }) => (
  <div className="tab-navigation">
    <button onClick={() => onTabChange('practice')} className={activeTab === 'practice' ? 'active' : ''}>Practice</button>
    <button onClick={() => onTabChange('fullTest')} className={activeTab === 'fullTest' ? 'active' : ''}>Full test</button>
    <button onClick={() => onTabChange('discussion')} className={activeTab === 'discussion' ? 'active' : ''}>Discussion</button>
  </div>
);

export default TabNavigation;
