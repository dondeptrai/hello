import React from 'react';

const TestInfo = ({ title, duration, questions, commentCount }) => (
  <div className="test-info">
    <h2>{title}</h2>
    <p>⏱ Time: {duration} minutes | 📋 {questions} question </p>
  </div>
);

export default TestInfo;
// | 💬 {commentCount} comment 