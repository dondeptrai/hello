import React from 'react';
import './PartSelection.css';
const PartSelection = ({ parts, onSelect }) => (
  <div className="part-selection">
    {parts.map(part => (
      <div key={part.id}>
        <input
          type="checkbox"
          id={`part-${part.id}`}
          checked={part.selected}
          onChange={() => onSelect(part.id)}
        />
        <label htmlFor={`part-${part.id}`}>{part.name} ({part.questionCount} questions)</label>
      </div>
    ))}
  </div>
);

export default PartSelection;
